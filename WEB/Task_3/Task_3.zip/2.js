function greeting(nam) {
    console.log("Привет, " + nam + "!")
}

greeting(prompt("Пожалуйста, представьтесь: "))